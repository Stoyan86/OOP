package WorkingWithAbstraction.Lab.PointInRectangle;

public class Point {
    private int pointA;
    private int pointB;

    public int getPointA() {
        return pointA;
    }

    public int getPointB() {
        return pointB;
    }

    public Point(int pointA, int pointB ) {
        this.pointA = pointA;
        this.pointB = pointB;
    }
}
