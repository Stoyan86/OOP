package WorkingWithAbstraction.Exercises.TrafficLights;

public enum Signal {
    RED,
    GREEN,
    YELLOW

}
