package WorkingWithAbstraction.Exercises.CardSuit;

public enum CardsSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES;
    
}
